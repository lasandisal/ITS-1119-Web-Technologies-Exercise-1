document.addEventListener("click", function(e){
    const ripple = document.createElement("div");
    ripple.classList.add("ripple");

    // set ripple position exactly where mouse clicked
    ripple.style.left = e.clientX + "px";
    ripple.style.top = e.clientY + "px";

    document.body.appendChild(ripple);

    // remove after animation finishes
    setTimeout(() => {
        ripple.remove();
    }, 600);
});